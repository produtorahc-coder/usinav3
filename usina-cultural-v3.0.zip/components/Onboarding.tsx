
import React, { useState } from 'react';
import { ViewState } from '../types';

interface Props {
    onComplete: (data: { roles: string[], segments: string[] }) => void;
}

// Lista de Perfis (Step 1)
const ROLES = [
    { id: 'artista', label: 'Artista / Criativo', desc: 'Ator, Músico, Artista Plástico...' },
    { id: 'produtor', label: 'Produtor Cultural / Gestor', desc: 'Produção Executiva, Gestão de Projetos...' },
    { id: 'tecnico', label: 'Técnico de Espetáculo', desc: 'Luz, Som, Palco, Montagem, Roadie...' },
    { id: 'servico', label: 'Prestador de Serviço', desc: 'Contabilidade, Jurídico, Transporte...' },
    { id: 'educador', label: 'Educador / Oficineiro', desc: 'Workshops, Aulas, Palestras...' },
    { id: 'curador', label: 'Curador / Parecerista', desc: 'Seleção artística, Análise de editais...' },
];

// Lista Expandida de Segmentos (Step 2)
const SEGMENTS = [
    { id: 'musica', label: 'Música', desc: 'Erudita, Popular, DJ, Instrumentista', icon: 'music_note' },
    { id: 'artes_cenicas', label: '