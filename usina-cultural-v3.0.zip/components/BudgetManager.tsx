
import React, { useState } from 'react';
import { BudgetProject, BudgetItem, BudgetCategory, ViewState } from '../types';

// Declaração global para biblioteca externa
declare var html2pdf: any;

interface Props {
    onBack: () => void;
    onNavigate: (view: ViewState, params?: any) => void;
    activeProjectId?: string | null;
    isEmbedded?: boolean; // Nova prop para controlar o layout embutido
}

// Categorias padrão baseadas na imagem fornecida
const DEFAULT_CATEGORIES = [
    "1 - Pessoal - Profissionais da Área da Cultura",
    "2 - Pessoal - Demais Prestadores de Serviços",
    "3 - Equipamentos, Material e Estrutura",
    "4 - Logística",
    "5 - Divulgação, Mídia e Comunicação",
    "6 - Ações de Acessibilidade",
    "7 - Custos Administrativos",
    "8 - Taxas e Seguros"
];

// Mock de Projetos Master para vincular
const MOCK_MASTER_PROJECTS = [
    { id: 'master-1', name: 'Festival Urbrasil 2024' },
    { id: 'master-2', name: 'Curta Metragem: O Silêncio' },
    { id: 'master-3', name: 'Exposição Coletiva SP' }
];

const BudgetManager: React.FC<Props> = ({ onBack, onNavigate, activeProjectId, isEmbedded }) => {
    // --- ESTADO ---
    const [viewMode, setViewMode] = useState<'LIST' | 'EDITOR'>('LIST');
    const [projects, setProjects] = useState<BudgetProject[]>([
        {
            id: '1',
            projectId: 'master-1', // Exemplo vinculado
            name: 'Projeto Circulação - Lei Paulo Gustavo',
            lastEdited: '10/10/2023',
            status: 'Em Elaboração',
            categories: generateEmptyCategories()
        }
    ]);
    const [currentProject, setCurrentProject] = useState<BudgetProject | null>(null);

    // Estados dos Modais
    const [showSaveModal, setShowSaveModal] = useState(false);
    const [showLinkModal, setShowLinkModal] = useState(false);
    const [isExporting, setIsExporting] = useState(false);

    // Filter projects based on the active project context
    const visibleProjects = activeProjectId 
        ? projects.filter(p => p.projectId === activeProjectId) 
        : projects;

    // --- HELPERS ---
    function generateEmptyCategories(): BudgetCategory[] {
        return DEFAULT_CATEGORIES.map((name, index) => ({
            id: index + 1,
            name: name,
            items: [] 
        }));
    }

    const formatCurrency = (value: number) => {
        return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    };

    const calculateItemTotal = (item: BudgetItem) => {
        return item.quantity * item.unitFrequency * item.unitValue;
    };

    const calculateCategoryTotal = (category: BudgetCategory) => {
        return category.items.reduce((acc, item) => acc + calculateItemTotal(item), 0);
    };

    const calculateProjectTotal = (project: BudgetProject) => {
        return project.categories.reduce((acc, cat) => acc + calculateCategoryTotal(cat), 0);
    };

    // --- AÇÕES ---

    const handleCreateNew = () => {
        const newProject: BudgetProject = {
            id: Date.now().toString(),
            projectId: activeProjectId || null, // Auto-link logic
            name: activeProjectId ? 'Novo Orçamento Vinculado' : 'Novo Orçamento de Modelo',
            lastEdited: new Date().toLocaleDateString('pt-BR'),
            status: 'Em Elaboração',
            categories: generateEmptyCategories()
        };
        setProjects([...projects, newProject]);
        setCurrentProject(newProject);
        setViewMode('EDITOR');
    };

    const handleOpenProject = (project: BudgetProject) => {
        setCurrentProject(project);
        setViewMode('EDITOR');
    };

    const openLinkModal = () => {
        setShowLinkModal(true);
    };

    const handleLinkProject = (masterProjectId: string) => {
        if (!currentProject) return;

        const updatedProject = { ...currentProject, projectId: masterProjectId };
        setProjects(prev => prev.map(p => p.id === currentProject.id ? updatedProject : p));
        setCurrentProject(updatedProject);
        setShowLinkModal(false);
        alert(`Orçamento vinculado ao projeto selecionado!`);
    };

    const handleCreateNewProjectToLink = () => {
        setShowLinkModal(false);
        // Redireciona para o ProjectManager em modo de criação
        onNavigate(ViewState.MODULE_PROJECTS, { create: true });
    };

    const handleUnlinkProject = () => {
        if (!currentProject) return;
        if(window.confirm("Deseja desvincular este orçamento do projeto? Ele se tornará um modelo avulso.")) {
             const updatedProject = { ...currentProject, projectId: null };
             setProjects(prev => prev.map(p => p.id === currentProject.id ? updatedProject : p));
             setCurrentProject(updatedProject);
             setShowLinkModal(false);
        }
    };

    const handleAddItem = (categoryId: number) => {
        if (!currentProject) return;

        const newItem: BudgetItem = {
            id: Date.now().toString(),
            description: '',
            quantity: 1,
            unit: 'Serviço',
            unitFrequency: 1,
            unitValue: 0
        };

        const updatedCategories = currentProject.categories.map(cat => {
            if (cat.id === categoryId) {
                return { ...cat, items: [...cat.items, newItem] };
            }
            return cat;
        });

        setCurrentProject({ ...currentProject, categories: updatedCategories });
    };

    const handleUpdateItem = (categoryId: number, itemId: string, field: keyof BudgetItem, value: any) => {
        if (!currentProject) return;

        const updatedCategories = currentProject.categories.map(cat => {
            if (cat.id === categoryId) {
                const updatedItems = cat.items.map(item => {
                    if (item.id === itemId) {
                        return { ...item, [field]: value };
                    }
                    return item;
                });
                return { ...cat, items: updatedItems };
            }
            return cat;
        });

        setCurrentProject({ ...currentProject, categories: updatedCategories });
    };

    const handleRemoveItem = (categoryId: number, itemId: string) => {
        if (!currentProject) return;

        const updatedCategories = currentProject.categories.map(cat => {
            if (cat.id === categoryId) {
                return { ...cat, items: cat.items.filter(i => i.id !== itemId) };
            }
            return cat;
        });

        setCurrentProject({ ...currentProject, categories: updatedCategories });
    };

    const handleDeleteProject = (e: React.MouseEvent, projectId: string) => {
        e.stopPropagation();
        if (window.confirm('Tem certeza que deseja excluir este orçamento?')) {
            setProjects(projects.filter(p => p.id !== projectId));
        }
    };

    // --- SAVE LOGIC ---
    const handleSaveClick = () => {
        setShowSaveModal(true);
    };

    const confirmSave = (action: 'CONTINUE' | 'EXIT') => {
        if (!currentProject) return;
        
        // Simula salvamento
        const updatedList = projects.map(p => p.id === currentProject.id ? {...currentProject, lastEdited: new Date().toLocaleDateString('pt-BR')} : p);
        setProjects(updatedList);
        
        setShowSaveModal(false);

        if (action === 'EXIT') {
            setViewMode('LIST');
        } else {
             // Apenas um feedback visual rápido
             const originalName = currentProject.name;
             setCurrentProject({...currentProject, name: "Salvando..."});
             setTimeout(() => {
                 setCurrentProject({...currentProject, name: originalName});
             }, 500);
        }
    };

    // --- PDF EXPORT LOGIC ---
    const handleExportPDF = () => {
        if (!currentProject) return;
        setIsExporting(true);

        const element = document.getElementById('budget-printable-area');
        const opt = {
            margin:       [10, 10, 10, 10], // top, left, bottom, right
            filename:     `Orcamento_${currentProject.name.replace(/\s+/g, '_')}.pdf`,
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2, useCORS: true },
            jsPDF:        { unit: 'mm', format: 'a4', orientation: 'landscape' }
        };

        // Pequeno delay para garantir que o estado de renderização (se houver loading) não afete
        setTimeout(() => {
            html2pdf().from(element).set(opt).save().then(() => {
                setIsExporting(false);
            });
        }, 100);
    };

    // --- RENDER ---
    const containerClasses = isEmbedded 
        ? "h-full bg-white text-slate-800 p-4 font-sans rounded-xl overflow-hidden flex flex-col" 
        : "min-h-screen bg-[#101922] text-white p-6 md:p-12 font-sans";

    if (viewMode === 'LIST') {
        return (
            <div className={containerClasses}>
                {!isEmbedded && (
                    <header className="flex justify-between items-center mb-12">
                        <div className="flex items-center gap-4">
                            <button onClick={onBack} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors">
                                <span className="material-symbols-outlined">arrow_back</span>
                            </button>
                            <div>
                                <h1 className="text-3xl font-bold flex items-center gap-3">
                                    <span className="material-symbols-outlined text-purple-500 text-3xl">payments</span>
                                    Gestor Financeiro
                                </h1>
                                <p className="text-white/50">
                                    {activeProjectId 
                                        ? "Gerencie os orçamentos deste projeto." 
                                        : "Visão geral de todos os orçamentos e modelos."}
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <button 
                                onClick={() => onNavigate(ViewState.DASHBOARD)}
                                className="w-10 h-10 flex items-center justify-center rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
                                title="Ir para Dashboard"
                            >
                                <span className="material-symbols-outlined">dashboard</span>
                            </button>
                            <button 
                                onClick={handleCreateNew}
                                className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-purple-900/20 transition-transform active:scale-95"
                            >
                                <span className="material-symbols-outlined">add</span>
                                Novo Orçamento
                            </button>
                        </div>
                    </header>
                )}

                {isEmbedded && (
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                             <span className="material-symbols-outlined text-purple-600">table_chart</span>
                             Planilhas do Projeto
                        </h2>
                        <button 
                            onClick={handleCreateNew}
                            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 text-sm shadow-sm"
                        >
                            <span className="material-symbols-outlined text-sm">add</span>
                            Criar Nova Planilha
                        </button>
                    </div>
                )}

                <div className={`grid grid-cols-1 md:grid-cols-2 ${isEmbedded ? 'lg:grid-cols-2' : 'lg:grid-cols-3'} gap-6`}>
                    {visibleProjects.map(project => (
                        <div 
                            key={project.id}
                            onClick={() => handleOpenProject(project)}
                            className={`${isEmbedded ? 'bg-white border-gray-200 hover:border-purple-500 shadow-sm' : 'bg-[#1c1c1e] border-white/5 hover:border-purple-500/50 hover:bg-[#1c1c1e]/80'} border rounded-2xl p-6 cursor-pointer transition-all group relative`}
                        >
                            <div className="flex justify-between items-start mb-4">
                                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isEmbedded ? 'bg-purple-100 text-purple-600' : 'bg-purple-500/20 text-purple-500'}`}>
                                    <span className="material-symbols-outlined text-2xl">table_chart</span>
                                </div>
                                <div className="flex gap-2">
                                     {/* Link Status Badge */}
                                    {project.projectId ? (
                                        <div className={`px-2 py-1 rounded text-[10px] font-bold border flex items-center gap-1 ${isEmbedded ? 'bg-blue-50 text-blue-600 border-blue-200' : 'bg-blue-500/20 text-blue-400 border-blue-500/30'}`}>
                                            <span className="material-symbols-outlined text-[10px]">link</span>
                                            Vinculado
                                        </div>
                                    ) : (
                                        <div className={`px-2 py-1 rounded text-[10px] font-bold border ${isEmbedded ? 'bg-gray-100 text-gray-500 border-gray-200' : 'bg-white/5 text-white/40 border-white/10'}`}>
                                            Avulso
                                        </div>
                                    )}

                                    <div className={`px-2 py-1 rounded text-[10px] font-bold border ${project.status === 'Finalizado' ? 'bg-green-500/20 text-green-500 border-green-500/30' : 'bg-yellow-500/20 text-yellow-500 border-yellow-500/30'}`}>
                                        {project.status}
                                    </div>
                                </div>
                            </div>
                            <h3 className={`text-xl font-bold mb-2 transition-colors ${isEmbedded ? 'text-slate-800 group-hover:text-purple-600' : 'text-white group-hover:text-purple-400'}`}>{project.name}</h3>
                            <div className="flex flex-col gap-1 mb-6">
                                <p className={`text-sm ${isEmbedded ? 'text-slate-500' : 'text-white/50'}`}>Editado em: {project.lastEdited}</p>
                                <p className={`text-2xl font-bold mt-2 ${isEmbedded ? 'text-slate-900' : 'text-white'}`}>{formatCurrency(calculateProjectTotal(project))}</p>
                            </div>
                            <div className={`flex items-center justify-between text-xs font-bold uppercase tracking-wider transition-colors ${isEmbedded ? 'text-slate-400 group-hover:text-purple-600' : 'text-white/40 group-hover:text-white'}`}>
                                <span>Abrir Planilha</span>
                                <span className="material-symbols-outlined">arrow_forward</span>
                            </div>
                            <button 
                                onClick={(e) => handleDeleteProject(e, project.id)}
                                className={`absolute top-4 right-4 p-2 transition-colors ${isEmbedded ? 'text-gray-300 hover:text-red-500' : 'text-white/20 hover:text-red-500'}`}
                            >
                                <span className="material-symbols-outlined">delete</span>
                            </button>
                        </div>
                    ))}
                    
                    {/* Empty State Helper */}
                    {visibleProjects.length === 0 && (
                        <div className={`col-span-full text-center py-20 flex flex-col items-center border border-dashed rounded-2xl ${isEmbedded ? 'border-gray-300 bg-gray-50 text-slate-400' : 'border-white/10 bg-[#1c1c1e]/50 text-white/30'}`}>
                            <span className="material-symbols-outlined text-6xl mb-4">folder_off</span>
                            <p className={`text-lg font-bold ${isEmbedded ? 'text-slate-600' : 'text-white/70'}`}>Nenhum orçamento encontrado.</p>
                            <p className="text-sm">
                                {activeProjectId 
                                    ? "Este projeto ainda não possui planilhas vinculadas."
                                    : "Clique em 'Novo Orçamento' para começar."}
                            </p>
                        </div>
                    )}
                </div>
            </div>
        );
    }

    if (viewMode === 'EDITOR' && currentProject) {
        return (
            <div className={containerClasses.replace('overflow-hidden', '')}>
                {/* Editor Header */}
                <header className={`${isEmbedded ? 'bg-white border-b border-gray-200' : 'bg-[#1c1c1e] border-b border-white/10 sticky top-0'} p-4 z-50 shadow-sm`}>
                    <div className="max-w-[1800px] mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
                        <div className="flex items-center gap-4 w-full md:w-auto">
                            <button onClick={() => setViewMode('LIST')} className={`w-10 h-10 flex items-center justify-center rounded-full transition-colors ${isEmbedded ? 'hover:bg-gray-100 text-slate-600' : 'hover:bg-white/10 text-white'}`}>
                                <span className="material-symbols-outlined">arrow_back</span>
                            </button>
                            <div className="flex flex-col">
                                <input 
                                    type="text" 
                                    value={currentProject.name}
                                    onChange={(e) => setCurrentProject({...currentProject, name: e.target.value})}
                                    className={`bg-transparent text-lg md:text-xl font-bold focus:outline-none focus:border-b border-purple-500 w-full md:w-96 ${isEmbedded ? 'text-slate-800' : 'text-white'}`}
                                />
                                <div className="flex items-center gap-2 mt-1">
                                    <div className={`w-2 h-2 rounded-full ${currentProject.projectId ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                                    <span className={`text-[10px] uppercase font-bold ${isEmbedded ? 'text-slate-500' : 'text-white/50'}`}>
                                        {currentProject.projectId ? 'Vinculado ao Projeto Master' : 'Modo Rascunho / Modelo'}
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                        <div className="flex items-center gap-4 md:gap-8 w-full md:w-auto justify-between md:justify-end">
                            
                            {/* Toggle Link Button */}
                            <button 
                                onClick={openLinkModal}
                                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                                    currentProject.projectId 
                                        ? 'bg-green-900/30 border-green-500/50 text-green-400 hover:bg-green-900/50' 
                                        : isEmbedded ? 'bg-gray-100 border-gray-200 text-slate-500 hover:bg-gray-200' : 'bg-white/5 border-white/10 text-white/50 hover:bg-white/10'
                                }`}
                                title={currentProject.projectId ? "Clique para gerenciar vínculo" : "Clique para vincular a um projeto"}
                            >
                                <span className="material-symbols-outlined text-sm">
                                    {currentProject.projectId ? 'link' : 'link_off'}
                                </span>
                                {currentProject.projectId ? 'Vinculado' : 'Vincular'}
                            </button>

                            <div className="flex flex-col items-end">
                                <span className={`text-[10px] uppercase font-bold ${isEmbedded ? 'text-slate-500' : 'text-white/50'}`}>Custo Total</span>
                                <span className="text-xl md:text-2xl font-bold text-purple-400 font-mono">
                                    {formatCurrency(calculateProjectTotal(currentProject))}
                                </span>
                            </div>
                            <div className="flex items-center gap-2">
                                <button 
                                    onClick={handleExportPDF}
                                    disabled={isExporting}
                                    className={`p-2 rounded-lg disabled:opacity-50 ${isEmbedded ? 'text-slate-600 hover:bg-gray-100' : 'text-white/70 hover:text-white bg-white/5 hover:bg-white/10'}`}
                                    title="Exportar PDF"
                                >
                                    {isExporting ? (
                                        <span className="material-symbols-outlined animate-spin">refresh</span>
                                    ) : (
                                        <span className="material-symbols-outlined">picture_as_pdf</span>
                                    )}
                                </button>
                                <button 
                                    onClick={handleSaveClick}
                                    className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 text-sm shadow-lg"
                                >
                                    <span className="material-symbols-outlined text-lg">save</span>
                                    Salvar
                                </button>
                            </div>
                        </div>
                    </div>
                </header>

                {/* Spreadsheet Area */}
                <div className={`flex-1 overflow-x-auto ${isEmbedded ? 'p-2' : 'p-4 md:p-8'}`}>
                    <div id="budget-printable-area" className="max-w-[1800px] mx-auto bg-white text-black shadow-2xl rounded-sm overflow-hidden min-w-[1000px]">
                        
                        {/* Table Header */}
                        <div className="grid grid-cols-[60px_1fr_80px_100px_100px_140px_140px_50px] bg-gray-200 border-b-2 border-gray-300 font-bold text-xs uppercase tracking-wider text-gray-700">
                            <div className="p-3 border-r border-gray-300 text-center">N.</div>
                            <div className="p-3 border-r border-gray-300">Descrição</div>
                            <div className="p-3 border-r border-gray-300 text-center">Qtde.</div>
                            <div className="p-3 border-r border-gray-300 text-center">Unidade</div>
                            <div className="p-3 border-r border-gray-300 text-center">Qtde. Unid.</div>
                            <div className="p-3 border-r border-gray-300 text-right">Valor Unit.</div>
                            <div className="p-3 border-r border-gray-300 text-right bg-gray-300">Subtotal</div>
                            <div className="p-3 text-center" data-html2pdf-ignore="true"></div>
                        </div>

                        {/* Categories & Items */}
                        {currentProject.categories.map((category) => (
                            <div key={category.id}>
                                {/* Category Header */}
                                <div className="bg-gray-100 p-2 font-bold text-sm text-gray-800 border-b border-gray-300 pl-4 uppercase">
                                    {category.name}
                                </div>

                                {/* Items Rows */}
                                {category.items.map((item, index) => (
                                    <div key={item.id} className="grid grid-cols-[60px_1fr_80px_100px_100px_140px_140px_50px] border-b border-gray-200 hover:bg-blue-50 transition-colors items-center text-sm">
                                        <div className="p-2 text-center text-gray-500 font-mono text-xs">
                                            {category.id}.{index + 1}
                                        </div>
                                        <div className="p-1 border-r border-gray-100">
                                            <input 
                                                type="text" 
                                                value={item.description}
                                                onChange={(e) => handleUpdateItem(category.id, item.id, 'description', e.target.value)}
                                                className="w-full bg-transparent p-1 outline-none focus:bg-white focus:ring-1 focus:ring-purple-500 rounded"
                                                placeholder="Descrição do item"
                                            />
                                        </div>
                                        <div className="p-1 border-r border-gray-100">
                                            <input 
                                                type="number" 
                                                min="0"
                                                value={item.quantity}
                                                onChange={(e) => handleUpdateItem(category.id, item.id, 'quantity', parseFloat(e.target.value) || 0)}
                                                className="w-full text-center bg-transparent p-1 outline-none focus:bg-white focus:ring-1 focus:ring-purple-500 rounded"
                                            />
                                        </div>
                                        <div className="p-1 border-r border-gray-100">
                                            <input 
                                                type="text"
                                                list="units" 
                                                value={item.unit}
                                                onChange={(e) => handleUpdateItem(category.id, item.id, 'unit', e.target.value)}
                                                className="w-full text-center bg-transparent p-1 outline-none focus:bg-white focus:ring-1 focus:ring-purple-500 rounded"
                                            />
                                            <datalist id="units">
                                                <option value="Serviço" />
                                                <option value="Cachê" />
                                                <option value="Verba" />
                                                <option value="Mês" />
                                                <option value="Semana" />
                                                <option value="Unidade" />
                                                <option value="Diária" />
                                            </datalist>
                                        </div>
                                        <div className="p-1 border-r border-gray-100">
                                             <input 
                                                type="number"
                                                min="0" 
                                                value={item.unitFrequency}
                                                onChange={(e) => handleUpdateItem(category.id, item.id, 'unitFrequency', parseFloat(e.target.value) || 0)}
                                                className="w-full text-center bg-transparent p-1 outline-none focus:bg-white focus:ring-1 focus:ring-purple-500 rounded"
                                            />
                                        </div>
                                        <div className="p-1 border-r border-gray-100">
                                            <input 
                                                type="number" 
                                                min="0"
                                                step="0.01"
                                                value={item.unitValue}
                                                onChange={(e) => handleUpdateItem(category.id, item.id, 'unitValue', parseFloat(e.target.value) || 0)}
                                                className="w-full text-right bg-transparent p-1 outline-none focus:bg-white focus:ring-1 focus:ring-purple-500 rounded"
                                            />
                                        </div>
                                        <div className="p-2 text-right font-mono bg-gray-50 border-r border-gray-200">
                                            {formatCurrency(calculateItemTotal(item))}
                                        </div>
                                        <div className="p-1 text-center" data-html2pdf-ignore="true">
                                            <button 
                                                onClick={() => handleRemoveItem(category.id, item.id)}
                                                className="text-gray-400 hover:text-red-500 p-1 rounded hover:bg-red-50"
                                            >
                                                <span className="material-symbols-outlined text-lg">close</span>
                                            </button>
                                        </div>
                                    </div>
                                ))}

                                {/* Add Item Row */}
                                <div className="p-2 border-b border-gray-300 bg-gray-50 flex justify-between items-center group" data-html2pdf-ignore="true">
                                    <button 
                                        onClick={() => handleAddItem(category.id)}
                                        className="text-xs font-bold text-purple-600 hover:text-purple-800 flex items-center gap-1 px-2 py-1 rounded hover:bg-purple-100 transition-colors"
                                    >
                                        <span className="material-symbols-outlined text-sm">add</span>
                                        Adicionar Item
                                    </button>
                                    <div className="text-right text-xs pr-4">
                                        <span className="text-gray-500 uppercase mr-2 font-bold">Total da Linha:</span>
                                        <span className="font-mono font-bold text-gray-800">{formatCurrency(calculateCategoryTotal(category))}</span>
                                    </div>
                                </div>
                            </div>
                        ))}

                        {/* Grand Total Footer */}
                        <div className="bg-gray-800 text-white p-6 flex justify-end items-center gap-6">
                            <span className="uppercase tracking-widest font-bold text-sm text-gray-400">Total Geral do Projeto</span>
                            <span className="text-3xl font-mono font-bold text-green-400">
                                {formatCurrency(calculateProjectTotal(currentProject))}
                            </span>
                        </div>
                    </div>
                </div>

                {/* --- MODAL: SALVAR --- */}
                {showSaveModal && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm px-4">
                        <div className="bg-[#1c1c1e] border border-white/10 rounded-2xl p-6 max-w-sm w-full shadow-2xl animate-fade-in">
                            <h3 className="text-xl font-bold mb-4 text-white">Salvar Alterações</h3>
                            <p className="text-white/60 mb-8 text-sm">
                                Suas alterações foram registradas. O que deseja fazer agora?
                            </p>
                            <div className="flex flex-col gap-3">
                                <button 
                                    onClick={() => confirmSave('CONTINUE')}
                                    className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-xl transition-colors"
                                >
                                    Salvar e Continuar Editando
                                </button>
                                <button 
                                    onClick={() => confirmSave('EXIT')}
                                    className="w-full bg-white/10 hover:bg-white/20 text-white font-bold py-3 rounded-xl transition-colors"
                                >
                                    Salvar e Voltar para Lista
                                </button>
                                <button 
                                    onClick={() => setShowSaveModal(false)}
                                    className="w-full text-white/40 hover:text-white text-sm py-2 transition-colors"
                                >
                                    Cancelar
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                 {/* --- MODAL: VINCULAR PROJETO --- */}
                 {showLinkModal && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm px-4">
                        <div className="bg-[#1c1c1e] border border-white/10 rounded-2xl p-6 max-w-md w-full shadow-2xl animate-fade-in">
                            <div className="flex justify-between items-center mb-6">
                                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                                    <span className="material-symbols-outlined text-purple-500">link</span>
                                    Vincular a um Projeto
                                </h3>
                                <button onClick={() => setShowLinkModal(false)} className="text-white/30 hover:text-white">
                                    <span className="material-symbols-outlined">close</span>
                                </button>
                            </div>
                            
                            <p className="text-white/60 mb-4 text-sm">
                                Selecione um projeto Master existente para associar a este orçamento. Um projeto pode ter múltiplas planilhas.
                            </p>

                            <div className="space-y-2 mb-6 max-h-60 overflow-y-auto">
                                {MOCK_MASTER_PROJECTS.map(proj => (
                                    <button 
                                        key={proj.id}
                                        onClick={() => handleLinkProject(proj.id)}
                                        className={`w-full text-left p-3 rounded-xl border flex items-center justify-between group transition-colors ${currentProject.projectId === proj.id ? 'bg-purple-900/20 border-purple-500' : 'bg-black/20 border-white/5 hover:border-purple-500/50'}`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center">
                                                <span className="material-symbols-outlined text-white/50 text-sm">folder</span>
                                            </div>
                                            <span className={`text-sm font-bold ${currentProject.projectId === proj.id ? 'text-purple-400' : 'text-white'}`}>
                                                {proj.name}
                                            </span>
                                        </div>
                                        {currentProject.projectId === proj.id && <span className="material-symbols-outlined text-purple-500 text-sm">check_circle</span>}
                                    </button>
                                ))}
                            </div>

                            <div className="border-t border-white/10 pt-4 flex flex-col gap-3">
                                <button 
                                    onClick={handleCreateNewProjectToLink}
                                    className="w-full flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 text-white border border-white/10 py-3 rounded-xl font-bold transition-colors"
                                >
                                    <span className="material-symbols-outlined">add_circle</span>
                                    Criar Novo Projeto Master
                                </button>

                                {currentProject.projectId && (
                                    <button 
                                        onClick={handleUnlinkProject}
                                        className="w-full text-red-400 hover:text-red-300 text-sm py-2 transition-colors flex items-center justify-center gap-2"
                                    >
                                        <span className="material-symbols-outlined text-sm">link_off</span>
                                        Desvincular Orçamento
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        );
    }

    return null;
};

export default BudgetManager;
