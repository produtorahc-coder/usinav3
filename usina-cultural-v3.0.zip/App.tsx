
import React, { useState, useEffect } from 'react';
import LandingPage from './components/LandingPage';
import OrbitPage from './components/OrbitPage';
import Dashboard from './components/Dashboard';
import EditalAnalyzer from './components/EditalAnalyzer';
import BudgetManager from './components/BudgetManager';
import CareerMode from './components/CareerMode';
import TeamManager from './components/TeamManager';
import AdminEdictsManager from './components/AdminEdictsManager'; 
import AdminPanel from './components/AdminPanel';
import PortfolioGenerator from './components/PortfolioGenerator';
import PlansPage from './components/PlansPage';
import ProjectManager from './components/ProjectManager';
import ProfileView from './components/ProfileView';
import SupportCenter from './components/SupportCenter';
import AllToolsPage from './components/AllToolsPage';
import Onboarding from './components/Onboarding'; 
import { ViewState } from './types';
import { RealTimeProvider, useRealTime } from './components/RealTimeContext';

const AppContent: React.FC = () => {
    const [currentView, setCurrentView] = useState<ViewState>(ViewState.LANDING);
    const [targetProjectId, setTargetProjectId] = useState<string | null>(null);
    const [initialCreate, setInitialCreate] = useState(false);
    const { on, off } = useRealTime();
    const [toast, setToast] = useState<{title: string, message: string} | null>(null);

    // Mock Context Data
    const MOCK_USER_EMAIL = "produtorahc@gmail.com"; // Simulação de Login

    // Mock User State (Simulating Database) - Updated for Arrays
    const [userProfile, setUserProfile] = useState<{
        roles: string[];
        segments: string[];
        isConfigured: boolean;
    }>({ roles: [], segments: [], isConfigured: false });

    // Global Listener for Deadline Alerts
    useEffect(() => {
        const handleAlert = (data: any) => {
            setToast({ title: data.title, message: data.message });
            setTimeout(() => setToast(null), 5000);
        };

        on('alerta-prazo', handleAlert);
        return () => off('alerta-prazo', handleAlert);
    }, [on, off]);

    const navigate = (view: ViewState, params?: any) => {
        // Intercept Logic: If trying to access app (Orbit/Dashboard) without config, force Onboarding
        if (
            (view === ViewState.ORBIT || view === ViewState.DASHBOARD) && 
            !userProfile.isConfigured
        ) {
            setCurrentView(ViewState.ONBOARDING);
            return;
        }

        if (params?.projectId) {
            setTargetProjectId(params.projectId);
        } else {
            if(view !== ViewState.MODULE_BUDGET && view !== ViewState.MODULE_PROJECTS) {
                setTargetProjectId(null);
            }
        }

        if (params?.create) {
            setInitialCreate(true);
        } else {
            setInitialCreate(false);
        }

        setCurrentView(view);
        window.scrollTo(0, 0);
    };

    const handlePlanSelection = (planName: string) => {
        const confirm = window.confirm(`Você selecionou o plano ${planName}.\n\nDeseja confirmar a assinatura e desbloquear os recursos?`);
        
        if (confirm) {
            alert(`Parabéns! Você agora é um assinante ${planName}.\nBem-vindo à elite da produção cultural.`);
            if (!userProfile.isConfigured) {
                navigate(ViewState.ONBOARDING);
            } else {
                navigate(ViewState.ORBIT);
            }
        }
    };

    const handleOnboardingComplete = (data: { roles: string[], segments: string[] }) => {
        // 1. Atualiza o estado global (Simulando persistência local pós-API)
        setUserProfile({
            roles: data.roles,
            segments: data.segments,
            isConfigured: true
        });

        // 2. Lógica de Roteamento Baseada no Usuário
        // Se for o Master, vai direto para o Admin Dashboard conforme solicitado.
        if (MOCK_USER_EMAIL === 'produtorahc@gmail.com') {
            navigate(ViewState.ADMIN_DASHBOARD);
        } else {
            // Usuários normais vão para a Órbita
            navigate(ViewState.ORBIT);
        }
    };

    const isAdminView = (view: ViewState) => {
        return view.startsWith('ADMIN_') && view !== ViewState.ADMIN_EDICTS; 
    };

    const renderView = () => {
        if (isAdminView(currentView)) {
            return <AdminPanel currentView={currentView} onNavigate={navigate} />;
        }

        switch (currentView) {
            case ViewState.LANDING:
                return <LandingPage onNavigate={navigate} />;
            case ViewState.ONBOARDING:
                return <Onboarding onComplete={handleOnboardingComplete} />;
            case ViewState.ORBIT:
                // Pass user profile formatted for display
                return <OrbitPage 
                    onNavigate={navigate} 
                    userSegment={userProfile.segments.join(', ')} 
                    userRole={userProfile.roles.join(' • ')} 
                />;
            case ViewState.DASHBOARD:
                return <Dashboard onNavigate={navigate} />;
            case ViewState.MODULE_EDITAL:
                return <EditalAnalyzer onBack={() => navigate(ViewState.ORBIT)} onNavigate={navigate} />;
            case ViewState.MODULE_BUDGET:
                return (
                    <BudgetManager 
                        onBack={() => navigate(ViewState.ORBIT)} 
                        onNavigate={navigate}
                        activeProjectId={targetProjectId}
                    />
                );
            case ViewState.MODULE_CAREER:
                return <CareerMode onBack={() => navigate(ViewState.ORBIT)} onNavigate={navigate} />;
            case ViewState.MODULE_TEAM:
                return <TeamManager onBack={() => navigate(ViewState.ORBIT)} onNavigate={navigate} />;
            case ViewState.ADMIN_EDICTS: 
                return <AdminEdictsManager onBack={() => navigate(ViewState.ORBIT)} onNavigate={navigate} />;
            case ViewState.MODULE_PORTFOLIO:
                return <PortfolioGenerator onBack={() => navigate(ViewState.ORBIT)} onNavigate={navigate} />;
            case ViewState.MODULE_PROJECTS:
                return (
                    <ProjectManager 
                        onBack={() => navigate(ViewState.ORBIT)} 
                        onNavigate={navigate} 
                        initialProjectId={targetProjectId}
                        initialCreate={initialCreate}
                    />
                );
            case ViewState.MODULE_PROFILE:
                // Pass raw arrays to ProfileView for detailed editing/viewing
                return <ProfileView 
                    onBack={() => navigate(ViewState.DASHBOARD)} 
                    onLogout={() => navigate(ViewState.LANDING)} 
                    userProfile={userProfile}
                />;
            case ViewState.SUPPORT:
                return <SupportCenter onBack={() => navigate(ViewState.DASHBOARD)} onNavigate={navigate} />;
            case ViewState.PLANS:
                return <PlansPage onBack={() => navigate(ViewState.ORBIT)} onSelectPlan={handlePlanSelection} />;
            case ViewState.ALL_TOOLS:
                return <AllToolsPage onBack={() => navigate(ViewState.DASHBOARD)} onNavigate={navigate} />;
            default:
                return <OrbitPage onNavigate={navigate} userSegment={userProfile.segments.join(', ')} userRole={userProfile.roles.join(' • ')} />;
        }
    };

    return (
        <div className="min-h-screen bg-[#121212] text-white font-sans antialiased selection:bg-primary selection:text-white relative">
            {renderView()}
            
            {toast && (
                <div className="fixed top-4 right-4 z-[100] bg-[#1c1c1e] border-l-4 border-red-500 text-white p-4 rounded shadow-2xl animate-fade-in max-w-sm">
                    <div className="flex items-start gap-3">
                        <span className="material-symbols-outlined text-red-500 animate-pulse">warning</span>
                        <div>
                            <h4 className="font-bold text-sm">{toast.title}</h4>
                            <p className="text-xs text-white/80 mt-1">{toast.message}</p>
                        </div>
                        <button onClick={() => setToast(null)} className="text-white/30 hover:text-white ml-2">
                            <span className="material-symbols-outlined text-sm">close</span>
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

const App: React.FC = () => {
    return (
        <RealTimeProvider>
            <AppContent />
        </RealTimeProvider>
    );
};

export default App;
